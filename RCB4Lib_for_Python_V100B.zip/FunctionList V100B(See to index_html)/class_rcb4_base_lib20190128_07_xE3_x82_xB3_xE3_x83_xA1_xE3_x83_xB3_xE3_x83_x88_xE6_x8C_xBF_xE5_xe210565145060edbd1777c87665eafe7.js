var class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7 =
[
    [ "CIRCLE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a7d447969f1f9db1121cc11be8c0dba23", null ],
    [ "CROSS", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#ace96eba06de29e84425a49c5c092e9ed", null ],
    [ "DOWN", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a66d442299f700fb353239914c1d43413", null ],
    [ "FALSE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a60351a7cb8e7ff5b0f26c2adc6c8294c", null ],
    [ "LEFT", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a3fd21b23c0e9121bc6c8de0bf850be2d", null ],
    [ "NONE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a64476e1c78d0c758fe2b58f981d1675a", null ],
    [ "RIGHT", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a03928fe0836508e07707ba0c25552c55", null ],
    [ "S1", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a07be840024947b37f7a87124afd583c5", null ],
    [ "S2", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a91ef38e7e1b378fd92d56a5aef23a49c", null ],
    [ "S3", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#af59c017d25c4772275ca1550d2fd9878", null ],
    [ "S4", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a29086a1656e274befbba402019fa0cd3", null ],
    [ "SQUARE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#a65dc8a528c15ac2b7a6e3a50209b2a52", null ],
    [ "TRIANGLE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#ad72ddc67593005c5ea52f971fe257b52", null ],
    [ "UP", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe210565145060edbd1777c87665eafe7.html#ab220eb1180d16edd945c444efe4bb21d", null ]
];