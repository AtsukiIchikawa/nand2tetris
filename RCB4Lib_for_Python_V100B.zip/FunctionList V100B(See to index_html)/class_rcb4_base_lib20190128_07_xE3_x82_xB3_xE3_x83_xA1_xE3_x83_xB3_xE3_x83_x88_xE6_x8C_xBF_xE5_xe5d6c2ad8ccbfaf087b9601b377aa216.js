var class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216 =
[
    [ "CIRCLE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#aec6f9a7085b614dc7a3fcb5043f6a728", null ],
    [ "CROSS", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#ac6966eee4453f926b638bcb0d76d3f23", null ],
    [ "DOWN", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#acce88394da12bc912007a2ab5acbc328", null ],
    [ "FALSE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#af9be9f8b204feb4a4e1cc5e7113e2fe8", null ],
    [ "LEFT", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#a49612bb8a69133e1dcdb10870425e7a9", null ],
    [ "NONE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#a0a223ce952c74eedae630deb6a9a5b4c", null ],
    [ "RIGHT", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#a1e1173de0b4d5ad63dc2b0c4c7c326c6", null ],
    [ "S1", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#ae11369d6e029b2b474da52afe63f04be", null ],
    [ "S2", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#ac788d5aa100f851693a25604592a02a3", null ],
    [ "S3", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#a20558dcf5f2b4ffcd2baefcaab8dc153", null ],
    [ "S4", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#ab4ca3499e9ca7e4d534d393ec4e8c308", null ],
    [ "SQUARE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#a28e08fc14a6835efbc584ab32e70e9ef", null ],
    [ "TRIANGLE", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#a781d85f4d8f9148feb2151cf4634669d", null ],
    [ "UP", "class_rcb4_base_lib20190128_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_xe5d6c2ad8ccbfaf087b9601b377aa216.html#ad06f6563bd569656e113ac264915171e", null ]
];