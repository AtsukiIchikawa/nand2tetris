var class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f =
[
    [ "CIRCLE", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a9c66efac6d4d19165e5603b1e5453dcf", null ],
    [ "CROSS", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a7fa82cb4a8c4662256ce91a7f05371f6", null ],
    [ "DOWN", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a5fa579e72336d109980d1388f3ecc76a", null ],
    [ "FALSE", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a02a2aeca1a1cfb034dc97a9b1423a108", null ],
    [ "LEFT", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a12dac63c844bef4d6ab69d5f9db843c2", null ],
    [ "NONE", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#afcff10bc1443920f5cb02bda5506e0c7", null ],
    [ "RIGHT", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#ae1c42bb95f80ef733df2c20ffd8b60b2", null ],
    [ "S1", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a167ff594a6f5355e141aa6fa8d5f7bf4", null ],
    [ "S2", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#afb2af27bd092e1027f31cde8c55e1190", null ],
    [ "S3", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a4e5590a02b64eb7dde260315d819697c", null ],
    [ "S4", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#aae7ab140cef60df7b73a93cfdad69319", null ],
    [ "SQUARE", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#ab81c68f7449f50993c050ef4bb8cc451", null ],
    [ "TRIANGLE", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#a87c9c3e33e74673329944fb0882bdf40", null ],
    [ "UP", "class_rcb4_base_lib20190204_07_xE3_x82_xB3_xE3_x83_xA1_xE3_x83_xB3_xE3_x83_x88_xE6_x8C_xBF_xE5_x351341244a1cb3a0a2a8da6516dd4a3f.html#aa3b83fc4b321decc4907d0388471b586", null ]
];