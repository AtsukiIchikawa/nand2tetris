var class_rcb4_base_lib_1_1_rcb4_base_lib_1_1_ack_type =
[
    [ "Ack", "class_rcb4_base_lib_1_1_rcb4_base_lib_1_1_ack_type.html#a320d68508e996f67b1b65d94ba1b7264", null ],
    [ "Nack", "class_rcb4_base_lib_1_1_rcb4_base_lib_1_1_ack_type.html#a81534bce9360958d5107542fdf092001", null ]
];