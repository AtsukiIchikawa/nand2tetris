var class_rcb4_base_lib_1_1_rcb4_base_lib_1_1_cmd_ok_type =
[
    [ "Error", "class_rcb4_base_lib_1_1_rcb4_base_lib_1_1_cmd_ok_type.html#accf233c74775868c1c82d8dcaa87772d", null ],
    [ "Ok", "class_rcb4_base_lib_1_1_rcb4_base_lib_1_1_cmd_ok_type.html#aa20da7039d3b4e441816559eb580a9c3", null ]
];