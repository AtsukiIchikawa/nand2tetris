var indexSectionsWithContent =
{
  0: "_acdgikmorsuv",
  1: "acdkrs",
  2: "r",
  3: "_acgimorsu",
  4: "acdimsuv",
  5: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "全て",
  1: "クラス",
  2: "ファイル",
  3: "関数",
  4: "変数",
  5: "ページ"
};

